# Welcome
This repository contains all of the necessary documents, images, files and HTML pages for our site
## Structure 
All of the important documents (pdf) and meeting reports can be found in the [documents](https://github.com/Triskaidekaphobiacs/triskaidekaphobiacs.github.io/tree/master/documents/meetings) folder
## Why?
For the last two semesters (2015-2016) we have been working on a C++ 3D UML project for classes "Team Project I" and "Team Project II". This site is a part of the project's presentation layer and it's purpose is to capture our progress.
## Who are we?
A team of seven master's degree students (Software Engineering) @ <http://www.fiit.stuba.sk>
## Contact us
<triskaidekaphobiacs@googlegroups.com>  


